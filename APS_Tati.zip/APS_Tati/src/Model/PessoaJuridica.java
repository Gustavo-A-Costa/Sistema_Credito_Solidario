
package Model;


public class PessoaJuridica extends Doador{
    private final float ALIQUOTA_PJ = 0.05f;    
}
