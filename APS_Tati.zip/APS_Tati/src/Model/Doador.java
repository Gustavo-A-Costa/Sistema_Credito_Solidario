
package Model;


public abstract class Doador {
    protected String nome;
    protected int codigoDoador;
    protected Doacao[] doacoes = new Doacao[1000]; // Necessario definir o tamanho do array
}
