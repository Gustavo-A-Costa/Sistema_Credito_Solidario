
package Model;


public class PessoaFisica extends Doador{
    private final float ALIQUOTA_PF = 0.03f;    
}
