
package model;


public class PessoaJuridica extends Doador {
    
    public void impromeDados(){
        System.out.println("Creditos: ");
        
    }
    @Override
    public void calculoCredito(){
        return ;
    }
    
}
