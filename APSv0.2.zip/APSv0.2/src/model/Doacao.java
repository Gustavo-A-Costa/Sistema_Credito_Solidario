
package model;


public class Doacao  {
    private int codigoDoador;
    private ItemDoacao[] itens = new ItemDoacao[100];//falta tamanho do array
    
    public void calculoCreditoDoacao(){
//        if pessoaFisica(){
//            itens/*cal1*/
//            return /* resultado */;
//        }
//        else {
//            itens/*cal2*/
//            return /* resultado */;
//        };
    }
}
