
package model;


public class PessoaFisica extends Doador {
    
    public void imprimeDados(){
        System.out.println("Creditos: ");
        
    }
    @Override
    public void calculoCredito(){
        return ;
    }
    
}
