
package Model;


public class Doacao {
    private int codigoDoador;
    
}
