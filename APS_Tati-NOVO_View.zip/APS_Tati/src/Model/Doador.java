
package Model;


public abstract class Doador {

    public Doador(String text, String text1) {
    }
    protected String nome;
    protected String codigoDoador;
    protected Doacao[] doacoes = new Doacao[1000]; // Necessario definir o tamanho do array
}
