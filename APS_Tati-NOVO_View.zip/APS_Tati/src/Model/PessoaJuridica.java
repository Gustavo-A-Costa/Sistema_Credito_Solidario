
package Model;


public class PessoaJuridica extends Doador{

    public PessoaJuridica() {
        super(cx_ID.getText(), cxNome.getText());
    }
    private final float ALIQUOTA_PJ = 0.05f;    
}
