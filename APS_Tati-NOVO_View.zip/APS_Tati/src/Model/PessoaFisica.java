
package Model;


public class PessoaFisica extends Doador{

    public PessoaFisica() {
        super(cx_ID.getText(), cxNome.getText());
    }
    private final float ALIQUOTA_PF = 0.03f;    
}
