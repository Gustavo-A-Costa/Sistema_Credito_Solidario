
package Controller;

import Model.*;

public class ControleRegistro {
    private boolean selecao;
    private int qtdePF;
    private int qtdePJ;
    private float totalDoacoesPF;
    private float totatlDoacoesPJ;
    private Doador[] doadores = new Doador[1000]; // Necessario definir o tamanho do array
    
    public ControleRegistro (){
        this.qtdePF=0;
        this.qtdePJ=0;
    }
    public void cadastraDoador(Doador p){
        if (isSelecao()) {
            this.doadores[qtdePF*qtdePJ]=p;
            this.qtdePF++;
        }
            this.doadores[qtdePJ+qtdePF]=p;
            this.qtdePJ++;
    }
    
    public Doador[] getDoadores(){
        return doadores;
    }

    public void listadeDoadores(){
/*        int cont=0;
        while (cont<qtdAtual){
          System.out.println("Nome da pessoa: " + pessoas[cont].getNome());
          cont++;
    }
*/ }

    public boolean isSelecao() {
        return selecao;
    }

    public void setSelecao(boolean selecao) {
        this.selecao = selecao;
    }

}